import { Component, OnInit } from '@angular/core';
import { DatePipe, CommonModule } from '@angular/common';
import { ReunionesService, Reunion } from '../../services/reuniones.service';
import { AuthService } from '../../core/auth.service';
import { MiniReunionesComponent } from '../home/mini-reuniones/mini-reuniones.component';


@Component({
  selector: 'app-alumno-reuniones',
  standalone: true,
  imports: [CommonModule, MiniReunionesComponent],
  templateUrl: './alumno-reuniones.component.html'
})
export class AlumnoReunionesComponent implements OnInit {

  reuniones: any[] = [];
  cargando = true;

  constructor(
    private reunServ: ReunionesService,
    private auth: AuthService
  ) {}

  ngOnInit() {
    const id = this.auth.getId(); // alumno logueado

    this.reunServ.getReunionesAlumno(id).subscribe({
      next: (lista) => {
        this.reuniones = lista;
        this.cargando = false;
      },
      error: (err) => {
        console.error(err);
        this.cargando = false;
      }
    });
  }
}

