import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './auth.service';
import { Observable } from 'rxjs';
import { filter, map, take } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {

    return this.auth.user$.pipe(

      // 🔥 Esperar a que el usuario esté cargado (null o usuario real)
      filter(user => user !== undefined), // evita evaluar antes de tiempo

      take(1),

      map(user => {

        // No logueado → fuera
        if (!user) {
          this.router.navigate(['/login']);
          return false;
        }

        const role = Number(user.tipo_id);

        // Redirección automática solo si entra a "/" o "/home"
        if (state.url === '/') {

          if (role === 1) {
            this.router.navigate(['/god/admins']);
            return false;
          }

          if (role === 2) {
            this.router.navigate(['/god/profesores']);
            return false;
          }

          if (role === 3) {
            this.router.navigate(['/prof/horario']);
            return false;
          }

          if (role === 4) {
            this.router.navigate(['/alumno/horario']);
            return false;
          }
        }

        return true;
      })
    );
  }
}
