import { Component } from '@angular/core';

@Component({
  selector: 'app-centros',
  imports: [],
  templateUrl: './centros.html',
  styleUrl: './centros.scss',
})
export class Centros {

}
