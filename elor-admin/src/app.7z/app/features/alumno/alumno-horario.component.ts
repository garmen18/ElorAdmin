import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorariosService, HorarioItem } from '../../services/horarios.service';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-alumno-horario',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './alumno-horario.component.html'
})
export class AlumnoHorarioComponent implements OnInit {

  dias = ['LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES'];
  horas = [1, 2, 3, 4, 5, 6];

  tabla: any = {}; // tabla[dia][hora] = HorarioItem

  constructor(
    private horarios: HorariosService,
    private auth: AuthService
  ) {}

  ngOnInit() {
    const id = this.auth.getUser().id;

    this.horarios.getHorarioAlumno(id).subscribe((lista: HorarioItem[]) => {

      // Filtrar guardias y tutorías
      const filtrado = lista.filter(item =>
        item.modulo.toLowerCase() !== 'guardia' &&
        item.modulo.toLowerCase() !== 'tutoria'
      );

      this.tabla = this.horarios.buildTablaHorario(filtrado);
    });
  }
}
