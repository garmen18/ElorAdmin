import { Component, OnInit } from '@angular/core';
import { CommonModule, NgIf } from '@angular/common';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterOutlet, NgIf],
  templateUrl: './layout.html',
  styleUrls: ['./layout.scss']
})
export class Layout implements OnInit {

  tipo: number | null = null;
  cargado = false; 

  constructor(
    private auth: AuthService, 
    public router: Router) {}
  

  ngOnInit() {
    this.auth.user$.subscribe(user => {
      this.tipo = user ? Number(user.tipo_id) : 0;
      this.cargado = true; 
    });
  }

  logout() {
    this.auth.logout();
  }
}
