import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs';
import { Observable } from 'rxjs';

export interface HorarioItem {
  id: number;
  dia: string;        // LUNES, MARTES...
  hora: number;       // 1..6
  modulo: string;     // nombre del módulo
  aula: string | null;
  observaciones: string | null;
}

@Injectable({
  providedIn: 'root'
})
export class HorariosService {

  private api = 'http://localhost:3000/horarios';

  constructor(private http: HttpClient) {}

  // ============================================================
  // HORARIO PROFESOR
  // ============================================================
  getHorarioProfesor(profeId: number): Observable<HorarioItem[]> {
    return this.http.get<any[]>(`${this.api}/profesor/${profeId}`).pipe(
      map(lista => this.mapearHorario(lista))
    );
  }

  // ============================================================
  // HORARIO ALUMNO
  // ============================================================
  getHorarioAlumno(alumId: number): Observable<HorarioItem[]> {
    return this.http.get<any[]>(`${this.api}/alumno/${alumId}`).pipe(
      map(lista => this.mapearHorario(lista))
    );
  }

  // ============================================================
  // MAPEO COMÚN PARA PROFESOR Y ALUMNO
  // ============================================================
  private mapearHorario(lista: any[]): HorarioItem[] {
    return lista.map(item => ({
      id: item.id,
      dia: item.dia,
      hora: item.hora,
      modulo: item.modulo_nombre,   // el backend debe devolverlo así
      aula: item.aula,
      observaciones: item.observaciones
    }));
  }

  // ============================================================
  // UTILIDAD PARA TABLA COMPLETA (profesor/alumno)
  // ============================================================
  buildTablaHorario(horario: HorarioItem[]) {
    const dias = ['LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES'];
    const horas = [1, 2, 3, 4, 5, 6];

    const tabla: any = {};

    dias.forEach(d => {
      tabla[d] = {};
      horas.forEach(h => tabla[d][h] = null);
    });

    horario.forEach(item => {
      tabla[item.dia][item.hora] = item;
    });

    return tabla;
  }
}
