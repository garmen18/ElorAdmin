import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-mini-horario',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './mini-horario.component.html'
})
export class MiniHorarioComponent implements OnChanges {

  @Input() datos: any[] = [];
  filas: any[] = [];

  ngOnChanges(changes: SimpleChanges) {
    if (changes['datos']) {
      this.filas = this.datos.slice(0, 3);
    }
  }
}
