import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from '../core/auth.service';
import { Observable } from 'rxjs';
import { filter, map, take } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProfesorGuard implements CanActivate {

  constructor(private auth: AuthService, private router: Router) {}

  canActivate(): Observable<boolean> {

    return this.auth.user$.pipe(

      // 🔥 Esperar a que el usuario esté cargado (null o usuario real)
      filter(user => user !== undefined),

      take(1),

      map(user => {

        // No logueado → login
        if (!user) {
          this.router.navigate(['/login']);
          return false;
        }

        // Logueado pero NO es profesor → home
        if (Number(user.tipo_id) !== 3) {
          this.router.navigate(['/home']);
          return false;
        }

        // Es profesor → acceso permitido
        return true;
      })
    );
  }
}
