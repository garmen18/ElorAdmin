import { Component, OnInit } from '@angular/core';
import { ReunionesService, Reunion } from '../../services/reuniones.service';
import { AuthService } from '../../core/auth.service';
import { CommonModule } from '@angular/common';
import { MiniReunionesComponent } from '../home/mini-reuniones/mini-reuniones.component';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-profesor-reuniones',
  standalone: true,
  templateUrl: './profesor-reuniones.component.html',
  imports: [CommonModule, MiniReunionesComponent, FormsModule]
})
export class ProfesorReunionesComponent implements OnInit {

  reuniones: Reunion[] = [];
  cargando = true;

  // 🔥 IDIOMA ACTUAL
  lang = 'es';

  // 🔥 TEXTOS TRADUCIDOS
  textos: any = {
    es: {
      misReuniones: 'Mis reuniones',
      cargando: 'Cargando...',
      crearNueva: 'Crear nueva reunión',
      nuevaReunion: 'Nueva reunión',
      alumno: 'Alumno (ID)',
      fecha: 'Fecha',
      hora: 'Hora',
      centro: 'Centro (CCEN)',
      titulo: 'Título',
      asunto: 'Asunto',
      aula: 'Aula',
      crear: 'Crear reunión'
    },
    eu: {
      misReuniones: 'Nire bilerak',
      cargando: 'Kargatzen...',
      crearNueva: 'Bilera berria sortu',
      nuevaReunion: 'Bilera berria',
      alumno: 'Ikaslea (ID)',
      fecha: 'Data',
      hora: 'Ordua',
      centro: 'Zentroa (CCEN)',
      titulo: 'Izenburua',
      asunto: 'Gaia',
      aula: 'Gela',
      crear: 'Bilera sortu'
    },
    en: {
      misReuniones: 'My meetings',
      cargando: 'Loading...',
      crearNueva: 'Create new meeting',
      nuevaReunion: 'New meeting',
      alumno: 'Student (ID)',
      fecha: 'Date',
      hora: 'Time',
      centro: 'Center (CCEN)',
      titulo: 'Title',
      asunto: 'Subject',
      aula: 'Room',
      crear: 'Create meeting'
    }
  };

  // 🔥 FUNCIÓN PARA OBTENER TEXTO
  t(key: string) {
    return this.textos[this.lang][key];
  }

  // 🔥 CAMBIAR IDIOMA
  cambiarIdioma(idioma: string) {
    this.lang = idioma;
  }

  form = {
    profesor_id: 0,
    alumno_id: null,
    fecha: '',
    hora: '',
    id_centro: '15112',
    titulo: '',
    asunto: '',
    aula: ''
  };

  constructor(
    private reunServ: ReunionesService,
    private auth: AuthService
  ) {}

  ngOnInit() {
    this.cargarReuniones();
  }

  cargarReuniones() {
    const id = this.auth.getId();
    this.reunServ.getReunionesProfesor(id).subscribe({
      next: (lista) => {
        this.reuniones = lista;
        this.cargando = false;
      },
      error: (err) => {
        console.error(err);
        this.cargando = false;
      }
    });
  }

  crearReunion() {
    this.form.profesor_id = this.auth.getId();

    this.reunServ.crearReunion(this.form).subscribe({
      next: () => {
        alert(this.t('crear') + ' ✔');
        this.cargarReuniones();
      },
      error: (err: any) => {
        console.error(err);
        alert('Error');
      }
    });
  }
}
