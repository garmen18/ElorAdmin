import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { UsuariosService } from '../../services/usuarios.service';
import { HorariosService, HorarioItem } from '../../services/horarios.service';
import { ReunionesService, Reunion } from '../../services/reuniones.service';
import { CommonModule, NgFor, NgIf, DatePipe } from '@angular/common';

@Component({
  selector: 'app-usuario-detalle',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    NgIf,
    NgFor,
    DatePipe
  ],
  templateUrl: './usuario-detalle.component.html'
})
export class UsuarioDetalleComponent implements OnInit {

  id!: number;
  usuario: any = null;

  horario: HorarioItem[] = [];
  tablaHorario: any = null;

  reuniones: Reunion[] = [];

  loading = true;
  error: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private usuarios: UsuariosService,
    private horariosSrv: HorariosService,
    private reunionesSrv: ReunionesService
  ) {}

  ngOnInit() {
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    this.cargarUsuario();
  }

  cargarUsuario() {
    this.loading = true;

    // Primero intentamos alumno
    this.usuarios.getAlumnoById(this.id).subscribe({
      next: alumno => {
        if (alumno) {
          this.usuario = alumno;
          this.cargarHorarioAlumno();
          this.cargarReunionesAlumno();
        }
      },
      error: () => {
        // Si no es alumno, probamos profesor
        this.usuarios.getProfesorById(this.id).subscribe({
          next: prof => {
            if (prof) {
              this.usuario = prof;
              this.cargarHorarioProfesor();
              this.cargarReunionesProfesor();
            }
          },
          error: () => {
            this.error = 'Usuario no encontrado';
            this.loading = false;
          }
        });
      }
    });
  }

  // ============================
  // HORARIO
  // ============================

  cargarHorarioAlumno() {
    this.horariosSrv.getHorarioAlumno(this.id).subscribe(h => {
      this.horario = h;
      this.tablaHorario = this.horariosSrv.buildTablaHorario(h);
      this.loading = false;
    });
  }

  cargarHorarioProfesor() {
    this.horariosSrv.getHorarioProfesor(this.id).subscribe(h => {
      this.horario = h;
      this.tablaHorario = this.horariosSrv.buildTablaHorario(h);
      this.loading = false;
    });
  }

  // ============================
  // REUNIONES
  // ============================

  cargarReunionesAlumno() {
    this.reunionesSrv.getReunionesAlumno(this.id).subscribe(r => {
      this.reuniones = r;
    });
  }

  cargarReunionesProfesor() {
    this.reunionesSrv.getReunionesProfesor(this.id).subscribe(r => {
      this.reuniones = r;
    });
  }
}
