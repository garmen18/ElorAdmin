import { ApplicationConfig, provideBrowserGlobalErrorListeners } from '@angular/core';
import { provideRouter } from '@angular/router';
import { RouteReuseStrategy } from '@angular/router';

import { routes } from './app.routes';
import { provideHttpClient, withFetch } from '@angular/common/http';

import { NoReuseStrategy } from './core/no-reuse.strategy';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideRouter(routes),
    provideHttpClient(withFetch()),

    // 🔥 AÑADIR ESTO
    { provide: RouteReuseStrategy, useClass: NoReuseStrategy }
  ]
};


export const environment = {
  apiUrl: 'http://localhost:3000',
  mapboxToken: 'pk.eyJ1IjoiY2FybG9zODg4IiwiYSI6ImNta2VjNjcxazA0M3UzcHF0eG9ocWViamYifQ.rIQrWE_GkfZ6nG5MBno1Cg'
};
