import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

import { AuthService } from '../../core/auth.service';
import { UsuariosService } from '../../services/usuarios.service';
import { HorariosService } from '../../services/horarios.service';
import { ReunionesService } from '../../services/reuniones.service';

import { MiniHorarioComponent } from './mini-horario/mini-horario.component';
import { MiniReunionesComponent } from './mini-reuniones/mini-reuniones.component';

import { forkJoin, of } from 'rxjs';
import { filter, take, switchMap, catchError } from 'rxjs/operators';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    FormsModule,
    MiniHorarioComponent,
    MiniReunionesComponent
  ],
  templateUrl: './home.html'
})
export class HomeComponent implements OnInit {

  tipo: number = 0;
  user: any = null;

  // GOD / ADMIN
  stats: any;
  admins: any[] = [];
  profesores: any[] = [];
  alumnos: any[] = [];

  // BUSCADOR (solo God/Admin)
  buscados: any[] = [];
  textoBusqueda: string = '';

  // PROFESOR / ALUMNO
  miniHorario: any[] = [];
  proximasReuniones: any[] = [];

  constructor(
    private auth: AuthService,
    private usuarios: UsuariosService,
    private http: HttpClient,
    private horarios: HorariosService,
    private reuniones: ReunionesService
  ) {}

  ngOnInit() {
    // Esperar al user y lanzar las cargas dependientes de forma encadenada
    this.auth.user$.pipe(
      filter(u => !!u),
      take(1),
      switchMap(user => {
        this.user = user;
        this.tipo = Number(user.tipo_id);

        // GOD / ADMIN: ejecutar varias peticiones en paralelo
        if (this.tipo === 1 || this.tipo === 2) {
          return forkJoin({
            stats: this.http.get('http://localhost:3000/stats').pipe(catchError(() => of(null))),
            admins: this.usuarios.getAdministradores().pipe(catchError(() => of([]))),
            profesores: this.usuarios.getProfesores().pipe(catchError(() => of([]))),
            alumnos: this.usuarios.getAlumnos().pipe(catchError(() => of([])))
          });
        }

        // PROFESOR: horario + reuniones en paralelo
        if (this.tipo === 3) {
          return forkJoin({
            horario: this.horarios.getHorarioProfesor(user.id).pipe(catchError(() => of([]))),
            reuniones: this.reuniones.getReunionesProfesor(user.id).pipe(catchError(() => of([])))
          });
        }

        // ALUMNO: horario + reuniones en paralelo
        if (this.tipo === 4) {
          return forkJoin({
            horario: this.horarios.getHorarioAlumno(user.id).pipe(catchError(() => of([]))),
            reuniones: this.reuniones.getReunionesAlumno(user.id).pipe(catchError(() => of([])))
          });
        }

        return of(null);
      })
    ).subscribe(result => {
      if (!result) return;

      if (this.tipo === 1 || this.tipo === 2) {
        this.stats = (result as any).stats;
        this.admins = (result as any).admins || [];
        this.profesores = (result as any).profesores || [];
        this.alumnos = (result as any).alumnos || [];
      } else if (this.tipo === 3 || this.tipo === 4) {
        const r = result as any;
        this.miniHorario = this.extraerMiniHorario(r.horario || []);
        this.proximasReuniones = this.extraerProximasReuniones(r.reuniones || []);
      }
    }, err => {
      console.error('[HOME] error al cargar datos', err);
    });
  }

  // =========================
  // GOD / ADMIN
  // =========================

  cargarStats() {
    this.http.get('http://localhost:3000/stats')
      .pipe(catchError(() => of(null)))
      .subscribe(d => this.stats = d);
  }

  cargarListas() {
    this.usuarios.getAdministradores().pipe(catchError(() => of([]))).subscribe(a => this.admins = a);
    this.usuarios.getProfesores().pipe(catchError(() => of([]))).subscribe(p => this.profesores = p);
    this.usuarios.getAlumnos().pipe(catchError(() => of([]))).subscribe(a => this.alumnos = a);
  }

  borrarAdmin(id: number) {
    this.usuarios.borrarAdmin(id).subscribe(() => {
      this.admins = this.admins.filter(x => x.id !== id);
    });
  }

  borrarProfesor(id: number) {
    this.usuarios.borrarProfesor(id).subscribe(() => {
      this.profesores = this.profesores.filter(x => x.id !== id);
    });
  }

  borrarAlumno(id: number) {
    this.usuarios.borrarAlumno(id).subscribe(() => {
      this.alumnos = this.alumnos.filter(x => x.id !== id);
    });
  }

  // =========================
  // BUSCADOR (God/Admin)
  // =========================

  buscar() {
    if (this.textoBusqueda.trim().length === 0) {
      this.buscados = [];
      return;
    }

    this.usuarios.buscar(this.textoBusqueda).pipe(catchError(() => of([]))).subscribe((r: any[]) => {
      this.buscados = r;
    });
  }

  // =========================
  // PROFESOR
  // =========================

  cargarHomeProfesor() {
    const id = this.user.id;

    this.horarios.getHorarioProfesor(id).pipe(catchError(() => of([]))).subscribe(h => {
      this.miniHorario = this.extraerMiniHorario(h);
    });

    this.reuniones.getReunionesProfesor(id).pipe(catchError(() => of([]))).subscribe(r => {
      console.log("REUNIONES PROFESOR:", r);
      this.proximasReuniones = this.extraerProximasReuniones(r);
    });
  }

  // =========================
  // ALUMNO
  // =========================

  cargarHomeAlumno() {
    const id = this.user.id;

    this.horarios.getHorarioAlumno(id).pipe(catchError(() => of([]))).subscribe(h => {
      this.miniHorario = this.extraerMiniHorario(h);
    });

    this.reuniones.getReunionesAlumno(id).pipe(catchError(() => of([]))).subscribe(r => {
      this.proximasReuniones = this.extraerProximasReuniones(r);
    });
  }

  // =========================
  // HELPERS COMUNES
  // =========================

  private extraerMiniHorario(horario: any[]): any[] {
    return (horario || []).slice(0, 3);
  }

  private extraerProximasReuniones(reuniones: any[]): any[] {
    return (reuniones || []).slice(0, 3);
  }
}
