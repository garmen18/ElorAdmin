import { Component } from '@angular/core';

@Component({
  selector: 'app-alumno',
  imports: [],
  templateUrl: './alumno.html',
  styleUrl: './alumno.scss',
})
export class Alumno {

}
