import { Component } from '@angular/core';

@Component({
  selector: 'app-profesor',
  imports: [],
  templateUrl: './profesor.html',
  styleUrl: './profesor.scss',
})
export class Profesor {

}
