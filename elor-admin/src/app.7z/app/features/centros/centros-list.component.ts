import { Component, OnInit } from '@angular/core';
import { CentrosService, CentrosResponse } from '../../services/centros.service';
import { Centro } from '../../models/centro.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-centros-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './centros-list.component.html'
})
export class CentrosListComponent implements OnInit {
  filtros = { dtituc: 'Todos', dterre: 'Todos', dmunic: 'Todos', q: '' };
  page = 1;
  pageSize = 20;
  total = 0;
  items: Centro[] = [];
  cargando = false;

  dtitucOptions: string[] = [];
  dterreOptions: string[] = [];
  dmunicOptions: string[] = [];

  constructor(
    private centrosSvc: CentrosService,
    private router: Router
  ) {}

  ngOnInit() {
    // 🔥 Solución: retrasar la carga un tick para evitar el bug de "no carga a la primera"
    setTimeout(() => {
      this.cargarFiltrosIniciales();
      this.cargar();
    }, 0);
  }

  cargarFiltrosIniciales() {
    this.centrosSvc.getCentros({ page: 1, pageSize: 10000 }).subscribe(res => {
      const all = res.items;
      this.dtitucOptions = Array.from(new Set(all.map(c => c.dtituc || 'Otros'))).sort();
      this.dterreOptions = Array.from(new Set(all.map(c => c.dterr || 'Otros'))).sort();
      this.dmunicOptions = Array.from(new Set(all.map(c => c.dmunic || 'Otros'))).sort();
      this.dtitucOptions.unshift('Todos');
      this.dterreOptions.unshift('Todos');
      this.dmunicOptions.unshift('Todos');
    });
  }

  cargar(page = 1) {
    this.cargando = true;
    this.page = page;

    this.centrosSvc.getCentros({
      ...this.filtros,
      page: this.page,
      pageSize: this.pageSize
    }).subscribe({
      next: (res: CentrosResponse) => {
        this.items = res.items;
        this.total = res.total;
        this.cargando = false;
      },
      error: () => this.cargando = false
    });
  }

  get totalPages() {
    return Math.ceil(this.total / this.pageSize);
  }

  verDetalle(ccen: number) {
    this.router.navigate(['/centros', ccen]);
  }
}
