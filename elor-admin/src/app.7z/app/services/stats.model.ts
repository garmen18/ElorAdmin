export interface Stats {
  alumnos: number;
  profesores: number;
  reunionesHoy: number;
}
