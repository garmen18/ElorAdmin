import { Component } from '@angular/core';

@Component({
  selector: 'app-reuniones',
  imports: [],
  templateUrl: './reuniones.html',
  styleUrl: './reuniones.scss',
})
export class Reuniones {

}
