import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  providers: [] // ← aquí irán los servicios globales más adelante
})
export class CoreModule { }
