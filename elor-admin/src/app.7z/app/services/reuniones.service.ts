import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs';

export interface Reunion {
  id: number;
  fecha: string;
  hora?: string | null;   // <--- SOLUCIÓN
  asunto: string;
  estado?: string;         // <--- añádelo también
  alumno?: string;
  profesor?: string;
}


@Injectable({
  providedIn: 'root'
})
export class ReunionesService {

  private api = 'http://localhost:3000/reuniones';

  constructor(private http: HttpClient) {}

  // ============================================================
  // REUNIONES PROFESOR
  // ============================================================
  getReunionesProfesor(profeId: number): Observable<Reunion[]> {
    return this.http.get<any[]>(`${this.api}/profesor/${profeId}`).pipe(
      map(lista => this.mapearReuniones(lista))
    );
  }

  // ============================================================
  // REUNIONES ALUMNO
  // ============================================================
  getReunionesAlumno(alumId: number): Observable<Reunion[]> {
    return this.http.get<any[]>(`${this.api}/alumno/${alumId}`).pipe(
      map(lista => this.mapearReuniones(lista))
    );
  }
crearReunion(data: any) {
  return this.http.post('http://localhost:3000/reuniones', data);
}

  // ============================================================
  // MAPEO COMÚN PARA PROFESOR Y ALUMNO
  // ============================================================
  private mapearReuniones(lista: any[]): Reunion[] {
  return lista
    .map(item => ({
      id: item.id,
      fecha: item.fecha,          
      hora: null,                 // OK si la interfaz lo permite
      asunto: item.asunto,
      estado: item.estado,        // <--- AÑADIDO
      alumno: item.alumno_nombre || null,
      profesor: item.profesor_nombre || null
    }))
    .sort((a, b) => {
      const fechaA = new Date(a.fecha).getTime();
      const fechaB = new Date(b.fecha).getTime();
      return fechaA - fechaB;
    });
}



}
