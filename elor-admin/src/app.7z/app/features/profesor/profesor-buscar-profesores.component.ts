import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { UsuariosService } from '../../services/usuarios.service';

@Component({
  selector: 'app-profesor-buscar-profesores',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './profesor-buscar-profesores.component.html'
})
export class ProfesorBuscarProfesoresComponent implements OnInit {

  profesores: any[] = [];
  profesoresFiltrados: any[] = [];
  filtro = '';

  constructor(
    private usuarios: UsuariosService,
    private router: Router
  ) {}

  ngOnInit() {
    this.usuarios.getProfesores().subscribe(p => {
      this.profesores = p;
      this.profesoresFiltrados = p;
    });
  }

  buscar() {
    const f = this.filtro.toLowerCase();

    this.profesoresFiltrados = this.profesores.filter(p =>
      p.nombre.toLowerCase().includes(f) ||
      p.apellidos.toLowerCase().includes(f) ||
      p.email.toLowerCase().includes(f)
    );
  }

  consultar(id: number) {
    this.router.navigate(['/usuario', id]);
  }
}
